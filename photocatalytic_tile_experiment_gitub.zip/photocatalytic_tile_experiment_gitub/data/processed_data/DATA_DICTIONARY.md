# Data dictionary

Both original CSV files have the same recorded columns. Empty trailing columns in the source files are retained so the files remain unchanged.

| Column | Meaning | Unit / interpretation |
| --- | --- | --- |
| `sample` | Sequential observation number | Integer index |
| `elapsed_ms` | Elapsed time recorded for the observation | Milliseconds |
| `mq3_raw` | Raw MQ-3 sensor analogue-to-digital converter reading | ADC counts; not calibrated to IPA concentration |
| `mq3_voltage` | MQ-3 output voltage recorded in the CSV | Volts; not calibrated to IPA concentration |
| blank columns | Empty fields present in the original CSV export | No recorded value |

`experiment_6 (5).csv` is the covered/dark run; `experiment_7.csv` is the natural-sunlight-exposed run, as identified in the manuscript and trace values. Each condition contains one run.