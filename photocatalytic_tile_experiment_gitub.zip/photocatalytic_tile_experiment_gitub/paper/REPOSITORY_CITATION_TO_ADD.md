# Add the repository citation after upload

This package is prepared for upload. It does not yet have a GitHub URL.

After creating the repository and setting it public:

1. Copy the exact public repository URL.
2. Add a Data Availability statement before the References section of the manuscript:

   `The original MQ-3 sensor data and analysis script are available at [PASTE PUBLIC REPOSITORY URL] (accessed [DATE]).`

3. Add and cite a numbered IEEE reference such as:

   `H. K. K. and K. O., “Raw MQ-3 Sensor Data for Dark and Sunlight Exposures of a TiO2-Based Composite Tile,” GitHub repository, 2026. [Online]. Available: [PASTE PUBLIC REPOSITORY URL]. [Accessed: DD-Mmm-YYYY].`

4. Replace the placeholders in the BibTeX starter below if the paper uses BibTeX:

```bibtex
@misc{harivardhan2026mq3data,
  author       = {Harivardhan K. K. and Karthikeyan O.},
  title        = {Raw MQ-3 Sensor Data for Dark and Sunlight Exposures of a TiO2-Based Composite Tile},
  year         = {2026},
  howpublished = {GitHub repository},
  url          = {https://github.com/USERNAME/REPOSITORY},
  note         = {Accessed: DD-Mmm-YYYY}
}
```

Do not submit the manuscript while any bracketed placeholders remain. If a Zenodo DOI is generated for a release, cite the DOI and version in preference to a mutable GitHub branch URL.