# License selection pending

No reuse license has been selected for these data or the analysis code. Before making the repository public, the authors/school should choose and add an appropriate license. For example, CC BY 4.0 is commonly used for datasets and MIT for code, but those licenses grant different permissions. This placeholder is not a license and does not grant reuse rights.