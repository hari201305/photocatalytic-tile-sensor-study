#!/usr/bin/env python3
"""Summarize the two original MQ-3 CSV runs and make reproducible SVG plots."""
from __future__ import annotations
import csv
import html
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUNS = [
    ("Covered", ROOT / "data/raw_data/experiment_6 (5).csv"),
    ("Sunlight-exposed", ROOT / "data/raw_data/experiment_7.csv"),
]


def read_run(path: Path):
    rows = []
    with path.open("r", newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            try:
                sample = int(float(row["sample"]))
                elapsed_ms = float(row["elapsed_ms"])
                raw = float(row["mq3_raw"])
                voltage = float(row["mq3_voltage"])
            except (KeyError, TypeError, ValueError):
                continue
            rows.append({"sample": sample, "elapsed_ms": elapsed_ms,
                         "mq3_raw": raw, "mq3_voltage": voltage})
    rows.sort(key=lambda r: r["sample"])
    if not rows:
        raise ValueError(f"No valid measurement rows found in {path}")
    return rows


def summarize(label, rows):
    values = [r["mq3_raw"] for r in rows]
    n10 = int(len(values) * 0.10)
    initial = statistics.mean(values[:n10])
    final = statistics.mean(values[-n10:])
    return {
        "condition": label,
        "valid_observations": len(values),
        "duration_min": (rows[-1]["elapsed_ms"] - rows[0]["elapsed_ms"]) / 60000,
        "mean_adc_counts": statistics.mean(values),
        "sample_sd_adc_counts": statistics.stdev(values) if len(values) > 1 else 0,
        "minimum_adc_counts": min(values),
        "maximum_adc_counts": max(values),
        "initial_10_percent_mean_adc": initial,
        "final_10_percent_mean_adc": final,
        "initial_to_final_change_percent": 100 * (final - initial) / initial,
        "first_elapsed_ms": rows[0]["elapsed_ms"],
        "last_elapsed_ms": rows[-1]["elapsed_ms"],
        "initial_10_percent_n": n10,
        "final_10_percent_n": n10,
    }


def write_summary(summaries):
    out = ROOT / "data/processed_data/summary_statistics.csv"
    fields = list(summaries[0].keys())
    with out.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for summary in summaries:
            row = {}
            for key, value in summary.items():
                row[key] = f"{value:.2f}" if isinstance(value, float) else value
            writer.writerow(row)


def svg_header(title, width, height):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            '<rect width="100%" height="100%" fill="white"/>',
            '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#222}.grid{stroke:#d9dee7;stroke-width:1}.axis{stroke:#333;stroke-width:1.3}.tick{font-size:13px}.label{font-size:15px}.title{font-size:19px;font-weight:bold}</style>',
            f'<text class="title" x="{width/2}" y="27" text-anchor="middle">{html.escape(title)}</text>']


def write_timeseries_svg(runs):
    width, height = 1000, 570
    left, right, top, bottom = 85, 965, 65, 485
    xmin, xmax, ymin, ymax = 0.0, 180.0, 2100.0, 2900.0
    X = lambda x: left + (x - xmin) / (xmax - xmin) * (right - left)
    Y = lambda y: bottom - (y - ymin) / (ymax - ymin) * (bottom - top)
    parts = svg_header("MQ-3 Response During Covered and Sunlight-Exposed Runs", width, height)
    for y in range(2100, 2901, 100):
        parts.append(f'<line class="grid" x1="{left}" y1="{Y(y):.1f}" x2="{right}" y2="{Y(y):.1f}"/>')
        parts.append(f'<text class="tick" x="{left-12}" y="{Y(y)+4:.1f}" text-anchor="end">{y}</text>')
    for x in range(0, 181, 30):
        parts.append(f'<line class="grid" x1="{X(x):.1f}" y1="{top}" x2="{X(x):.1f}" y2="{bottom}"/>')
        parts.append(f'<text class="tick" x="{X(x):.1f}" y="{bottom+23}" text-anchor="middle">{x}</text>')
    parts += [f'<line class="axis" x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}"/>',
              f'<line class="axis" x1="{left}" y1="{top}" x2="{left}" y2="{bottom}"/>',
              f'<text class="label" x="{(left+right)/2}" y="{height-30}" text-anchor="middle">Elapsed time (min)</text>',
              f'<text class="label" transform="translate(24 {(top+bottom)/2}) rotate(-90)" text-anchor="middle">MQ-3 raw response (ADC counts)</text>']
    colors = ["#2878B5", "#E87500"]
    for (label, rows), color in zip(runs, colors):
        points = " ".join(f"{X(r['elapsed_ms']/60000):.2f},{Y(r['mq3_raw']):.2f}" for r in rows)
        parts.append(f'<polyline fill="none" stroke="{color}" stroke-width="1.15" points="{points}"/>')
    parts += ['<rect x="720" y="74" width="225" height="53" fill="white" stroke="#aaa"/>',
              '<line x1="735" y1="92" x2="765" y2="92" stroke="#2878B5" stroke-width="3"/>',
              '<text class="tick" x="773" y="97">Covered</text>',
              '<line x1="735" y1="111" x2="765" y2="111" stroke="#E87500" stroke-width="3"/>',
              '<text class="tick" x="773" y="116">Sunlight-exposed</text>',
              '<text class="tick" x="500" y="548" text-anchor="middle">The two runs have different durations; one run was recorded per condition.</text>',
              '</svg>']
    out = ROOT / "results/figures/mq3_sensor_response.svg"
    out.write_text("\n".join(parts), encoding="utf-8")


def write_initial_final_svg(summaries):
    width, height = 820, 510
    left, right, top, bottom = 95, 785, 65, 420
    ymax = 3000
    y = lambda v: bottom - v / ymax * (bottom - top)
    parts = svg_header("Initial and Final 10% MQ-3 Response Means", width, height)
    for val in range(0, ymax+1, 500):
        parts.append(f'<line class="grid" x1="{left}" y1="{y(val):.1f}" x2="{right}" y2="{y(val):.1f}"/>')
        parts.append(f'<text class="tick" x="{left-12}" y="{y(val)+4:.1f}" text-anchor="end">{val}</text>')
    parts += [f'<line class="axis" x1="{left}" y1="{bottom}" x2="{right}" y2="{bottom}"/>',
              f'<line class="axis" x1="{left}" y1="{top}" x2="{left}" y2="{bottom}"/>']
    centers = [300, 585]
    colors = ["#2878B5", "#E87500"]
    for center, summary, condition in zip(centers, summaries, ["Covered", "Sunlight-exposed"]):
        vals = [summary["initial_10_percent_mean_adc"], summary["final_10_percent_mean_adc"]]
        for i, val in enumerate(vals):
            x = center - 47 + i * 58
            parts.append(f'<rect x="{x}" y="{y(val):.2f}" width="42" height="{bottom-y(val):.2f}" fill="{colors[i]}"/>')
        parts.append(f'<text class="tick" x="{center}" y="{bottom+25}" text-anchor="middle">{condition}</text>')
    parts += [f'<text class="label" x="{(left+right)/2}" y="{height-35}" text-anchor="middle">Run condition</text>',
              f'<text class="label" transform="translate(27 {(top+bottom)/2}) rotate(-90)" text-anchor="middle">Mean sensor response (ADC counts)</text>',
              '<rect x="565" y="75" width="205" height="52" fill="white" stroke="#aaa"/>',
              '<rect x="580" y="88" width="15" height="12" fill="#2878B5"/><text class="tick" x="603" y="99">Initial 10% mean</text>',
              '<rect x="580" y="107" width="15" height="12" fill="#E87500"/><text class="tick" x="603" y="118">Final 10% mean</text>',
              '<text class="tick" x="440" y="480" text-anchor="middle">Descriptive within-run comparison; no calibrated concentration or replicate uncertainty.</text>',
              '</svg>']
    out = ROOT / "results/figures/initial_final_10_percent_means.svg"
    out.write_text("\n".join(parts), encoding="utf-8")


def main():
    runs = [(label, read_run(path)) for label, path in RUNS]
    summaries = [summarize(label, rows) for label, rows in runs]
    write_summary(summaries)
    write_timeseries_svg(runs)
    write_initial_final_svg(summaries)
    for summary in summaries:
        print(summary["condition"], summary["valid_observations"],
              f"{summary['duration_min']:.2f} min",
              f"{summary['initial_to_final_change_percent']:.2f}%")

if __name__ == "__main__":
    main()